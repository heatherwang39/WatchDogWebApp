window._config = {
    cognito: {
        userPoolId: 'us-east-1_0jjbVupLN',
        region: 'us-east-1',
		clientId: '1eov611niga5sbrphdnboeoo3c'
    },
};